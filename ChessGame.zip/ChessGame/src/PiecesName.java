public enum PiecesName {
    King, Queen, Rook, Bishop, Knight, Pawn;
}