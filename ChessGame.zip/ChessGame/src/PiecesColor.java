public enum PiecesColor {
    Black, White;
}
